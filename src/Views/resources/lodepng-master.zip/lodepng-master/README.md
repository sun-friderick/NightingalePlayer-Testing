LodePNG
-------

PNG encoder and decoder in C and C++.

Home page: http://lodev.org/lodepng/

Only two files are needed to allow your program to read and write PNG files: lodepng.cpp and lodepng.h.

The other files in the project are just examples, unit tests, etc...
