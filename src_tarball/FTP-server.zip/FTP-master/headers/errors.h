#ifndef ERRORS_H
#define	ERRORS_H

void usage();

#endif