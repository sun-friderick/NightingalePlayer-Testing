#include "unp.h"
#include <time.h>
/* 
* unp.h库是《Unix Network Programming, Volume 1: The Sockets Networking API》书中所用的一个库
* 该程序实现的是一个基于poll和tcp的最简单的HTTP服务器。
*/
const static int OPEN_MAX=1024;
const static int PATH_MAX_LENGTH=128;

int					i, maxi, listenfd, connfd, sockfd;
int					nready;
ssize_t				n;
char				buf[MAXLINE],Response[MAXLINE];
socklen_t			clilen;
struct pollfd		client[1024];
struct sockaddr_in	cliaddr, servaddr;
time_t				ticks;
char			wwwroot[128];
int 			port=8080;
char contentType[20][100]= {"text/html","text/css","application/x-javascript","image/gif","image/jpeg","image/x-icon","image/png"};

void init_srv(){
	listenfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(2333);
}

void DealWithReq(int sockfd,char buf[],char *Response){
	int i,n,contType=0;
	FILE	*fp;
	char *blank=" ",*p;
	char tmp[128]="";
	char suffix[10];
	strcpy(tmp,wwwroot);
	p=strtok(buf,blank);
	p=strtok(NULL,blank);
	if(!strcmp(p,"/")){
		strcpy(p,"/index.html");
	}
	//if(strstr(p,"favicon.ico")){
	//	p="/favicon.ico";
	//}
	sscanf(p,"\%*[^.].%s",suffix);
	if(!strcmp(suffix,"html")){
		contType=0;
	}else if(!strcmp(suffix,"jpg")){
		contType=4;
	}else if(!strcmp(suffix,"ico")){
		contType=5;
	}else if(!strcmp(suffix,"gif")){
		contType=3;
	}else if(!strcmp(suffix,"css")){
		contType=1;
	}else if(!strcmp(suffix,"js")){
		contType=2;
	}else if(!strcmp(suffix,"png")){
		contType=6;
	}else{
		contType=0;
	}
	p=strcat(tmp,p);printf("%s\n",p);
	if(fp=fopen(p,"r")){
		char buff[MAXLINE];
		fseek(fp, 0L, SEEK_END);
		sprintf(Response,"HTTP/1.1 200 OK\r\nServer: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)\r\nContent-Length: %lu \r\nContent-Type: %s \r\n\r\n",ftell(fp),contentType[contType]);
		write(sockfd,Response, strlen(Response));
		/*
		*	open和fopen的句柄貌似很不一样啊？不是说fopen是open封装起来的么=。= ...
		*	用fopen的句柄不能read是怎么一回事呢？
		*/
		int *fd=open(p,O_RDONLY);
		while((n=read(fd,buff,MAXLINE))>0){
			write(sockfd,buff,n);
		}
	}else{
		char buff[MAXLINE];
		*tmp="";
		strcpy(tmp,wwwroot);
		strcat(tmp,"/404.html");
		printf("%s\n",tmp );
		sprintf(Response,"HTTP/1.1 404 Not Found\r\nServer: Apache/1.3.3.7 (Unix) (Red-Hat/Linux) \r\n\r\n");
		write(sockfd,Response,strlen(Response));
		int *fd=open(tmp,O_RDONLY);
		while((n=read(fd,buff,MAXLINE))>0){
			write(sockfd,buff,n);
		}
	}
	
}

int main(int argc, char const *argv[]){
	FILE *conf,*log;
	char *p;
	ticks = time(NULL);
	char date[MAXLINE]="./log/2015";
	strcat(date,".log");
	if( (conf=fopen("./conf/httpd.conf","r")) && (log=fopen(date,"w")) ){
		fgets(buf,128,conf);
		sscanf(buf, "%*[^=]=%i" ,&port);
		fgets(buf,128,conf);
		sscanf(buf, "%*[^=]=%s" , wwwroot);
		init_srv();
	}else{
		err_quit("无法初始化..");
	}

	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));
	Listen(listenfd, LISTENQ);
	client[0].fd = listenfd;
	client[0].events = POLLRDNORM;
	for (i = 1; i < OPEN_MAX; i++){
		client[i].fd = -1;		
	}
	maxi = 0;	
	while(1){
		nready = Poll(client, maxi+1, INFTIM);

		if (client[0].revents & POLLRDNORM) {	
			clilen = sizeof(cliaddr);
			connfd = Accept(listenfd, (SA *) &cliaddr, &clilen);
			/* log */
			for (i = 1; i < OPEN_MAX; i++){
				if (client[i].fd < 0) {
					client[i].fd = connfd;	
					break;
				}
			}
			if (i == OPEN_MAX){
				err_quit("too many clients");
			}
			client[i].events = POLLRDNORM;
			if (i > maxi){
				maxi = i;				
			}
			if (--nready <= 0){
				continue;
			}				
		}

		for (i = 1; i <= maxi; i++) {	
			if ( (sockfd = client[i].fd) < 0)
				continue;
			if (client[i].revents & (POLLRDNORM | POLLERR)) {
				if ( (n = read(sockfd, buf, MAXLINE)) < 0) {
					if (errno == ECONNRESET) {
						printf("client[%d] aborted connection\n", i);
						Close(sockfd);
						client[i].fd = -1;
					} else{
						err_sys("read error");
					}
				} else if (n == 0) {
					printf("client[%d] closed connection\n", i);
					Close(sockfd);
					client[i].fd = -1;
				} else{
					printf("From %s\n",Sock_ntop((SA *) &cliaddr, clilen));
					DealWithReq(sockfd,buf,&Response);
					//if(Response){
					//	Writen(sockfd,Response, n);
					//}else{
					//	sprintf(Response,"HTTP/1.1 501 Not implemented\r\nServer: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)\r\nContent-Length: %d \r\nContent-Type: text/html \r\n\r\n",0);
					//	Writen(sockfd,Response, n);
					//}
					Close(sockfd);
					client[i].fd = -1;
				}
				if (--nready <= 0){
					break;
				}
			}
		}
	}
}
